The initial conditions as PBM images are stored in this directory.
