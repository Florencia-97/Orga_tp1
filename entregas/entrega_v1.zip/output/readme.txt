The generated PBM images will be saved in this directory.
