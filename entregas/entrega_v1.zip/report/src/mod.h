#ifndef MOD__H
#define MOD__H

extern int mod(int x, int m);

#endif