#ifndef SHARED__H
#define SHARED__H

extern size_t times_called;
extern double mean_time;

#endif