#ifndef VECINOS__H
#define VECINOS__H

#include "mod.h"

extern unsigned int vecinos(unsigned char *a,
                            unsigned int i, unsigned int j,
                            unsigned int M, unsigned int N);

#endif
